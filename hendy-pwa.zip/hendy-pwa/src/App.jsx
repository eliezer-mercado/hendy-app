import { useState, useEffect, useRef } from "react";

// ─── DATA ─────────────────────────────────────────────────────────────────────
const QUESTIONS = [
  {
    id:"situacion", pregunta:"¿Cómo describirías tu situación económica hoy?",
    sub:"Sé honesto/a. Nadie más lo verá.",
    opciones:[
      {emoji:"🔥",label:"Hendy total",  desc:"No llego a fin de mes",        value:"hendy_total"},
      {emoji:"😓",label:"Ajustado",     desc:"Llego pero sin ahorrar nada",  value:"ajustado"},
      {emoji:"😐",label:"Estable",      desc:"Cubro mis gastos, algo queda", value:"estable"},
      {emoji:"💪",label:"Creciendo",    desc:"Ahorro y quiero invertir",     value:"creciendo"},
    ],
  },
  {
    id:"deuda", pregunta:"¿Tenés deudas o préstamos activos?",
    sub:"Incluye cuotas, fiado, préstamos de amigos.",
    opciones:[
      {emoji:"🚨",label:"Sí, me asfixian",  desc:"No puedo con los pagos", value:"deudas_criticas"},
      {emoji:"⚠️",label:"Sí, manejables",   desc:"Pago pero me ajusta",    value:"deudas_manejables"},
      {emoji:"📋",label:"Solo una pequeña", desc:"Casi la cancelo",        value:"deuda_chica"},
      {emoji:"✅",label:"Sin deudas",        desc:"Estoy limpio/a",         value:"sin_deudas"},
    ],
  },
  {
    id:"meta", pregunta:"¿Cuál es tu mayor sueño financiero ahora mismo?",
    sub:"Lo que más querés lograr en los próximos 12 meses.",
    opciones:[
      {emoji:"🏠",label:"Tener casa propia",desc:"O mejorar donde vivo",         value:"casa"},
      {emoji:"💼",label:"Emprender",         desc:"Arrancar o crecer mi negocio", value:"emprender"},
      {emoji:"🧘",label:"Tranquilidad",      desc:"Solo quiero dejar de deber",   value:"tranquilidad"},
      {emoji:"✈️",label:"Libertad",          desc:"Viajar, estudiar, crecer",     value:"libertad"},
    ],
  },
];

const LECCIONES_BASE = [
  {id:1,emoji:"🪙",titulo:"El truco del sobre",           duracion:"60 seg",categoria:"Ahorro",  preview:"La técnica más antigua del mundo — y la más efectiva para el trabajador informal."},
  {id:2,emoji:"📊",titulo:"¿Qué es un presupuesto real?", duracion:"60 seg",categoria:"Básicos", preview:"No es una planilla de Excel. Es saber adónde va cada guaraní antes de gastarlo."},
  {id:3,emoji:"🚨",titulo:"La deuda que más duele",       duracion:"60 seg",categoria:"Deudas",  preview:"No es la más grande. Es la que pagás con intereses sin darte cuenta."},
  {id:4,emoji:"💸",titulo:"Remesas sin perder plata",     duracion:"60 seg",categoria:"Pagos",   preview:"Cada vez que mandás dinero al exterior, alguien se queda con parte. Así lo evitás."},
  {id:5,emoji:"🌱",titulo:"El fondo de emergencia mínimo",duracion:"60 seg",categoria:"Ahorro",  preview:"No necesitás millones. Con esto alcanza para no endeudarte ante cualquier imprevisto."},
  {id:6,emoji:"🧾",titulo:"Fiado: cuándo sí y cuándo no",duracion:"60 seg",categoria:"Básicos", preview:"El fiado puede ser tu mejor aliado o tu peor trampa. La diferencia está en una sola regla."},
  {id:7,emoji:"📱",titulo:"PIX y pagos digitales",        duracion:"60 seg",categoria:"Pagos",   preview:"El sistema que cambió Brasil y que llegó al Mercosur. Cómo usarlo a tu favor."},
];

const BADGES = [
  {id:"primera_leccion", emoji:"🌱", titulo:"Primera chispa",    desc:"Completaste tu primera lección",        req: c => c >= 1},
  {id:"racha_3",         emoji:"🔥", titulo:"Racha de 3",        desc:"3 días seguidos aprendiendo",           req: (_,s) => s >= 3},
  {id:"mitad",           emoji:"⚡", titulo:"A mitad de camino", desc:"Completaste más de la mitad del plan",  req: c => c >= 4},
  {id:"sin_deudas",      emoji:"💪", titulo:"Mente clara",       desc:"Respondiste sobre tus deudas",          req: (_,__,u) => !!u?.answers},
  {id:"racha_7",         emoji:"🏆", titulo:"Una semana seguida",desc:"7 días de racha — eso es disciplina",   req: (_,s) => s >= 7},
  {id:"completo",        emoji:"🎓", titulo:"Graduado Hendy",    desc:"Completaste todas las lecciones",       req: c => c >= 7},
];

// ─── CSS ──────────────────────────────────────────────────────────────────────
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap');
  *{box-sizing:border-box;margin:0;padding:0;}

  @keyframes fadeUp      {from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:translateY(0)}}
  @keyframes fadeIn      {from{opacity:0}to{opacity:1}}
  @keyframes flicker     {0%,100%{opacity:1}45%{opacity:1}50%{opacity:.3}55%{opacity:1}80%{opacity:1}83%{opacity:.5}86%{opacity:1}}
  @keyframes slideOutUp  {from{opacity:1;transform:scale(1) translateY(0)}to{opacity:0;transform:scale(1.03) translateY(-12px)}}
  @keyframes pulseBtn    {0%,100%{box-shadow:0 0 0 0 rgba(255,75,43,.4)}50%{box-shadow:0 0 0 14px rgba(255,75,43,0)}}
  @keyframes orbFloat    {0%,100%{transform:translateY(0) translateX(0)}33%{transform:translateY(-22px) translateX(12px)}66%{transform:translateY(12px) translateX(-18px)}}
  @keyframes grain       {0%,100%{transform:translate(0,0)}10%{transform:translate(-2%,-3%)}20%{transform:translate(3%,2%)}40%{transform:translate(4%,-1%)}}
  @keyframes lineGrow    {from{width:0}to{width:60px}}
  @keyframes typingPulse {0%,80%,100%{opacity:0;transform:scale(.8)}40%{opacity:1;transform:scale(1)}}
  @keyframes resultSlide {from{opacity:0;transform:translateY(40px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
  @keyframes scoreCount  {from{opacity:0;transform:scale(.5)}to{opacity:1;transform:scale(1)}}
  @keyframes shimmer     {0%{background-position:-400px 0}100%{background-position:400px 0}}
  @keyframes streakPop   {0%{transform:scale(1)}40%{transform:scale(1.4)}100%{transform:scale(1)}}
  @keyframes progressFill{from{width:0%}to{width:var(--prog)}}
  @keyframes cardReveal  {from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  @keyframes checkPop    {0%{transform:scale(0) rotate(-10deg)}60%{transform:scale(1.2) rotate(3deg)}100%{transform:scale(1) rotate(0deg)}}
  @keyframes lessonIn    {from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
  @keyframes badgePop    {0%{transform:scale(0) rotate(-15deg);opacity:0}60%{transform:scale(1.15) rotate(3deg)}100%{transform:scale(1) rotate(0deg);opacity:1}}
  @keyframes toastSlide  {0%{transform:translateY(100px);opacity:0}15%{transform:translateY(0);opacity:1}80%{transform:translateY(0);opacity:1}100%{transform:translateY(100px);opacity:0}}
  @keyframes cursorBlink {0%,100%{opacity:1}50%{opacity:0}}

  .btn-primary{background:#FF4B2B;color:#fff;border:none;border-radius:16px;padding:18px 36px;font-family:'Syne',sans-serif;font-weight:700;font-size:16px;cursor:pointer;width:100%;transition:background .2s,transform .15s;animation:pulseBtn 2.5s ease-in-out infinite;}
  .btn-primary:hover{background:#e03d22;transform:scale(1.02);animation:none;}
  .btn-primary:disabled{background:#2a1510;color:#5a2a20;cursor:not-allowed;animation:none;}
  .btn-ghost{background:transparent;color:#555;border:1px solid #1e1e1e;border-radius:16px;padding:16px 36px;font-family:'DM Sans',sans-serif;font-size:14px;cursor:pointer;width:100%;transition:all .2s;margin-top:12px;}
  .btn-ghost:hover{border-color:#444;color:#ccc;}
  .opt-btn{background:#0e0e0e;border:1px solid #1e1e1e;border-radius:16px;padding:16px 20px;display:flex;align-items:center;gap:16px;cursor:pointer;transition:all .2s;text-align:left;width:100%;}
  .opt-btn:hover{border-color:#FF4B2B;background:#130a09;}
  .opt-btn.active{border-color:#FF4B2B;background:#1a0d09;}
  .stat-card{background:#111;border:1px solid #1e1e1e;border-radius:16px;padding:16px 20px;flex:1;transition:border-color .2s;}
  .stat-card:hover{border-color:#333;}
  .tag{display:inline-flex;align-items:center;gap:6px;background:#141414;border:1px solid #222;border-radius:100px;padding:6px 14px;font-size:12px;color:#888;font-family:'DM Sans',sans-serif;}
  .dot-live{width:6px;height:6px;border-radius:50%;background:#FF4B2B;animation:typingPulse 1.5s ease infinite;}
  .typing-dot{width:8px;height:8px;border-radius:50%;background:#FF4B2B;display:inline-block;}
  .typing-dot:nth-child(1){animation:typingPulse 1.2s .0s infinite}
  .typing-dot:nth-child(2){animation:typingPulse 1.2s .2s infinite}
  .typing-dot:nth-child(3){animation:typingPulse 1.2s .4s infinite}
  .result-card{background:#111;border:1px solid #1e1e1e;border-radius:20px;padding:20px;animation:resultSlide .6s ease both;}
  .shimmer-line{height:14px;border-radius:8px;background:linear-gradient(90deg,#1a1a1a 25%,#252525 50%,#1a1a1a 75%);background-size:800px 100%;animation:shimmer 1.5s infinite;}
  .lesson-card{background:#0e0e0e;border:1px solid #1e1e1e;border-radius:20px;padding:20px;cursor:pointer;transition:all .25s;width:100%;text-align:left;animation:cardReveal .4s ease both;}
  .lesson-card:hover{border-color:#FF4B2B33;background:#130a09;transform:translateY(-2px);}
  .lesson-card.completed{border-color:#4ade8033;background:#0a130a;}
  .lesson-card.active-today{border-color:#FF4B2B;background:#130a09;}
  .streak-badge{display:inline-flex;align-items:center;gap:8px;background:#1a1208;border:1px solid #3a2810;border-radius:100px;padding:8px 16px;}
  .progress-bar-bg{background:#1a1a1a;border-radius:100px;height:6px;overflow:hidden;}
  .progress-bar-fill{height:100%;background:#FF4B2B;border-radius:100px;animation:progressFill .8s ease forwards;}
  .category-pill{display:inline-flex;align-items:center;padding:4px 10px;border-radius:100px;font-size:11px;font-family:'DM Sans',sans-serif;font-weight:500;letter-spacing:.5px;}
  .nav-btn{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;background:none;border:none;cursor:pointer;padding:12px 8px;transition:opacity .2s;}

  @keyframes proGlow { 0%,100%{box-shadow:0 0 20px rgba(250,204,21,.15)} 50%{box-shadow:0 0 40px rgba(250,204,21,.3)} }
  @keyframes lockShake { 0%,100%{transform:translateX(0)} 20%,60%{transform:translateX(-4px)} 40%,80%{transform:translateX(4px)} }
  .pro-banner{background:linear-gradient(135deg,#1a1208,#120a1a);border:1px solid #facc1544;border-radius:20px;padding:24px;}
  .pro-feature{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #1a1a1a;}
  .pro-feature:last-child{border-bottom:none;}
  .lock-overlay{position:absolute;inset:0;background:rgba(10,10,10,.85);border-radius:20px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;backdrop-filter:blur(2px);}
  .feature-row{display:flex;align-items:flex-start;gap:16px;padding:18px 0;border-bottom:1px solid #161616;}
  .feature-row:last-child{border-bottom:none;}
  .badge-card{background:#0e0e0e;border:1px solid #1e1e1e;border-radius:16px;padding:16px;display:flex;align-items:center;gap:14px;transition:all .2s;}
  .badge-card.earned{border-color:#facc1544;background:#141008;}
  .badge-card.locked{opacity:.35;}
  .name-input{background:#111;border:1px solid #2a2a2a;border-radius:14px;padding:16px 20px;font-family:'Syne',sans-serif;font-size:22px;font-weight:700;color:#fff;width:100%;outline:none;transition:border-color .2s;text-align:center;letter-spacing:-.5px;}
  .name-input:focus{border-color:#FF4B2B;}
  .name-input::placeholder{color:#333;}
  .toast{position:fixed;bottom:100px;left:50%;transform:translateX(-50%);background:#1a1208;border:1px solid #FF4B2B44;border-radius:100px;padding:12px 24px;display:flex;align-items:center;gap:10px;z-index:200;animation:toastSlide 3.5s ease forwards;white-space:nowrap;}
`;

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const Ambient = () => (
  <>
    <div style={{position:"fixed",inset:0,zIndex:999,pointerEvents:"none",opacity:.035,
      backgroundImage:`url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
      animation:"grain .5s steps(1) infinite"}}/>
    <div style={{position:"fixed",top:"-10%",right:"-10%",width:400,height:400,borderRadius:"50%",pointerEvents:"none",
      background:"radial-gradient(circle,rgba(255,75,43,.12) 0%,transparent 70%)",animation:"orbFloat 8s ease-in-out infinite"}}/>
    <div style={{position:"fixed",bottom:"-15%",left:"-10%",width:500,height:500,borderRadius:"50%",pointerEvents:"none",
      background:"radial-gradient(circle,rgba(255,75,43,.07) 0%,transparent 70%)",animation:"orbFloat 10s ease-in-out infinite reverse"}}/>
  </>
);

const catColor = {Ahorro:"#facc15",Básicos:"#60a5fa",Deudas:"#f87171",Pagos:"#4ade80"};

// ─── SPLASH ───────────────────────────────────────────────────────────────────
const Splash = ({done}) => (
  <div style={{position:"fixed",inset:0,display:"flex",flexDirection:"column",alignItems:"center",
    justifyContent:"center",zIndex:100,background:"#0A0A0A",
    animation:done?"slideOutUp .5s ease forwards":"fadeIn .4s ease"}}>
    <div style={{textAlign:"center"}}>
      <div style={{fontSize:64,animation:"flicker 2s ease infinite",marginBottom:20,lineHeight:1}}>🔥</div>
      <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:52,color:"#fff",letterSpacing:"-2px",lineHeight:1}}>hendy</div>
      <div style={{height:2,background:"#FF4B2B",borderRadius:2,marginTop:10,animation:"lineGrow 1.5s ease forwards",width:0}}/>
      <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#555",marginTop:16,
        letterSpacing:"3px",textTransform:"uppercase",animation:"fadeIn 1s ease 1s both"}}>Dejá de estarlo.</div>
    </div>
  </div>
);

// ─── ONBOARDING — NOMBRE ──────────────────────────────────────────────────────
const NameScreen = ({onContinue}) => {
  const [name,setName] = useState("");
  const inputRef = useRef(null);
  useEffect(()=>{ setTimeout(()=>inputRef.current?.focus(),400); },[]);
  return (
    <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",
      justifyContent:"center",padding:"0 28px 60px",animation:"fadeIn .5s ease"}}>
      <div style={{textAlign:"center",marginBottom:40}}>
        <div style={{fontSize:56,animation:"flicker 2s ease infinite",marginBottom:16}}>🔥</div>
        <h1 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:32,color:"#fff",
          letterSpacing:"-1.5px",lineHeight:1.1,marginBottom:12}}>
          ¿Cómo te<br/><span style={{color:"#FF4B2B"}}>llamás?</span>
        </h1>
        <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:15,color:"#555",lineHeight:1.7}}>
          Tu coach necesita saber<br/>con quién está hablando.
        </p>
      </div>
      <input
        ref={inputRef}
        className="name-input"
        placeholder="Tu nombre aquí..."
        value={name}
        onChange={e=>setName(e.target.value)}
        onKeyDown={e=>e.key==="Enter"&&name.trim()&&onContinue(name.trim())}
        maxLength={20}
      />
      {name.trim() && (
        <div style={{marginTop:12,textAlign:"center",fontFamily:"'DM Sans',sans-serif",
          fontSize:13,color:"#555",animation:"fadeIn .3s ease"}}>
          Hola, <span style={{color:"#FF4B2B",fontWeight:600}}>{name.trim()}</span> 👋
        </div>
      )}
      <div style={{marginTop:32}}>
        <button className="btn-primary" onClick={()=>name.trim()&&onContinue(name.trim())} disabled={!name.trim()}>
          Empezar mi diagnóstico →
        </button>
      </div>
      <div style={{textAlign:"center",marginTop:20,fontFamily:"'DM Sans',sans-serif",
        fontWeight:300,fontSize:12,color:"#333"}}>
        Solo tu nombre. Nada más. 🔒
      </div>
    </div>
  );
};

// ─── HOME ─────────────────────────────────────────────────────────────────────
const Home = ({onStart,userName}) => (
  <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"0 0 100px",animation:"fadeIn .6s ease"}}>
    <div style={{padding:"56px 28px 0",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
      <div>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
          <span style={{fontSize:22}}>🔥</span>
          <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:24,color:"#fff",letterSpacing:"-1px"}}>hendy</span>
        </div>
        <div className="tag"><span className="dot-live"/><span>Coach financiero IA · Paraguay</span></div>
      </div>
    </div>
    <div style={{padding:"36px 28px 0",animation:"fadeUp .6s ease .1s both"}}>
      {userName && (
        <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#555",marginBottom:8}}>
          Hola, <span style={{color:"#FF4B2B",fontWeight:600}}>{userName}</span> 👋
        </div>
      )}
      <h1 style={{fontWeight:800,fontSize:40,color:"#fff",lineHeight:1.05,letterSpacing:"-1.5px",marginBottom:8}}>
        "Hendy" es<br/><span style={{color:"#FF4B2B"}}>donde estás.</span>
      </h1>
      <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:15,color:"#555",lineHeight:1.65,marginTop:14}}>
        La app que te entiende — y te ayuda a salir de ahí.
      </p>
    </div>
    <div style={{padding:"28px 28px 0",display:"flex",gap:12,animation:"fadeUp .6s ease .2s both"}}>
      {[{label:"Usuarios",val:"12K+",sub:"↑ creciendo",c:"#FF4B2B"},{label:"Lecciones",val:"60\"",sub:"por día",c:"#555"},{label:"Países",val:"5",sub:"Mercosur",c:"#555"}].map((s,i)=>(
        <div key={i} className="stat-card">
          <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:"#444",letterSpacing:"1px",textTransform:"uppercase",marginBottom:6}}>{s.label}</div>
          <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:22,color:"#fff",letterSpacing:"-1px"}}>{s.val}</div>
          <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:s.c,marginTop:2}}>{s.sub}</div>
        </div>
      ))}
    </div>
    <div style={{margin:"28px 28px 0",background:"#0e0e0e",border:"1px solid #181818",borderRadius:20,padding:"4px 20px",animation:"fadeUp .6s ease .3s both"}}>
      {[
        {icon:"🧠",bg:"#1a1208",label:"Diagnóstico personalizado",desc:"3 preguntas. Tu mapa financiero real."},
        {icon:"📅",bg:"#0d1a0d",label:"Micro-lecciones diarias",desc:"60 segundos. Lenguaje de la feria, no del banco."},
        {icon:"🏆",bg:"#1a1208",label:"Logros y badges",desc:"Ganá medallas por tu progreso y tu racha."},
        {icon:"💸",bg:"#1a0d0d",label:"Conectado a NXB",desc:"Mové tu plata sin comisiones cuando estés listo."},
      ].map((f,i)=>(
        <div key={i} className="feature-row">
          <div style={{width:44,height:44,borderRadius:12,background:f.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>{f.icon}</div>
          <div>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:14,color:"#ddd",marginBottom:3}}>{f.label}</div>
            <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#555",lineHeight:1.5}}>{f.desc}</div>
          </div>
        </div>
      ))}
    </div>
    <div style={{padding:"28px 28px 0",animation:"fadeUp .6s ease .5s both"}}>
      <button className="btn-primary" onClick={onStart}>Empezar mi diagnóstico →</button>
    </div>
    <div style={{textAlign:"center",marginTop:20,fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#333"}}>
      Gratis. Sin tarjeta. Solo tu decisión. 🔥
    </div>
  </div>
);

// ─── QUIZ ─────────────────────────────────────────────────────────────────────
const Quiz = ({onFinish,onBack,userName}) => {
  const [step,setStep]=useState(0);
  const [answers,setAnswers]=useState({});
  const [selected,setSelected]=useState(null);
  const [out,setOut]=useState(false);
  const q=QUESTIONS[step];
  const next=()=>{
    if(!selected)return;
    const na={...answers,[q.id]:selected};
    setOut(true);
    setTimeout(()=>{ if(step===QUESTIONS.length-1){onFinish(na);}else{setStep(s=>s+1);setSelected(null);setOut(false);} },320);
  };
  return (
    <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",
      padding:"56px 28px 32px",animation:out?"slideOutUp .32s ease forwards":"fadeIn .4s ease"}}>
      <button onClick={step===0?onBack:()=>{setStep(s=>s-1);setSelected(null);}}
        style={{background:"none",border:"none",color:"#555",cursor:"pointer",
          fontFamily:"'DM Sans',sans-serif",fontSize:14,display:"flex",alignItems:"center",gap:8,marginBottom:40,padding:0}}>
        ← {step===0?"Volver":"Anterior"}
      </button>
      <div style={{display:"flex",gap:6,marginBottom:48}}>
        {QUESTIONS.map((_,i)=>(<div key={i} style={{height:3,flex:1,borderRadius:2,background:i<=step?"#FF4B2B":"#1e1e1e",transition:"background .3s"}}/>))}
      </div>
      <div style={{flex:1,display:"flex",flexDirection:"column"}}>
        {userName&&<div style={{fontFamily:"'DM Sans',sans-serif",fontSize:13,color:"#444",marginBottom:8}}>{userName},</div>}
        <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#444",letterSpacing:"2px",textTransform:"uppercase",marginBottom:14}}>Pregunta {step+1} de {QUESTIONS.length}</div>
        <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:28,color:"#fff",letterSpacing:"-1px",lineHeight:1.15,marginBottom:10}}>{q.pregunta}</h2>
        <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#555",marginBottom:32,lineHeight:1.6}}>{q.sub}</p>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {q.opciones.map((opt,i)=>(
            <button key={opt.value} className={`opt-btn${selected===opt.value?" active":""}`}
              onClick={()=>setSelected(opt.value)} style={{animation:`fadeUp .35s ease ${i*.06}s both`}}>
              <span style={{fontSize:24,flexShrink:0}}>{opt.emoji}</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:15,color:"#ddd",marginBottom:2}}>{opt.label}</div>
                <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#555"}}>{opt.desc}</div>
              </div>
              <div style={{color:selected===opt.value?"#FF4B2B":"#333",fontSize:18,transition:"color .2s"}}>{selected===opt.value?"●":"›"}</div>
            </button>
          ))}
        </div>
      </div>
      <div style={{marginTop:32}}>
        <button className="btn-primary" onClick={next} disabled={!selected}>
          {step===QUESTIONS.length-1?"Ver mi diagnóstico 🔥":"Siguiente →"}
        </button>
      </div>
      <div style={{textAlign:"center",marginTop:16,fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#333"}}>Tus respuestas son 100% privadas 🔒</div>
    </div>
  );
};

// ─── LOADING ──────────────────────────────────────────────────────────────────
const Loading = ({userName}) => (
  <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",
    alignItems:"center",justifyContent:"center",padding:"0 28px",animation:"fadeIn .4s ease"}}>
    <div style={{fontSize:52,animation:"flicker 1.5s ease infinite",marginBottom:24}}>🔥</div>
    <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:24,color:"#fff",textAlign:"center",letterSpacing:"-1px",marginBottom:12}}>
      {userName?`Analizando tu situación,\n${userName}...`:"Analizando tu situación..."}
    </h2>
    <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#555",textAlign:"center",lineHeight:1.7,marginBottom:36}}>
      La IA está construyendo<br/>tu plan personalizado.
    </p>
    <div style={{display:"flex",gap:8}}><span className="typing-dot"/><span className="typing-dot"/><span className="typing-dot"/></div>
    <div style={{width:"100%",marginTop:48,display:"flex",flexDirection:"column",gap:12}}>
      {[100,80,65,90].map((w,i)=>(<div key={i} className="shimmer-line" style={{width:`${w}%`,animationDelay:`${i*.15}s`}}/>))}
    </div>
  </div>
);

// ─── RESULT ───────────────────────────────────────────────────────────────────
const Result = ({data,userName,onContinue}) => {
  const [copied,setCopied]=useState(false);
  const scoreColor=data.score>=70?"#4ade80":data.score>=40?"#facc15":"#FF4B2B";
  return (
    <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"56px 28px 100px",animation:"fadeIn .5s ease"}}>
      <div style={{textAlign:"center",marginBottom:24,animation:"scoreCount .6s ease .1s both",opacity:0}}>
        <div style={{display:"inline-flex",flexDirection:"column",alignItems:"center",background:"#0e0e0e",border:"1px solid #1e1e1e",borderRadius:24,padding:"22px 40px"}}>
          <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#444",letterSpacing:"2px",textTransform:"uppercase",marginBottom:8}}>
            {userName?"Diagnóstico de "+userName:"Tu puntaje Hendy"}
          </div>
          <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:60,color:scoreColor,lineHeight:1,letterSpacing:"-3px"}}>{data.score}</div>
          <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#444",marginTop:2}}>de 100</div>
        </div>
      </div>
      <div style={{animation:"fadeUp .5s ease .2s both",opacity:0}}>
        <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#FF4B2B",letterSpacing:"2px",textTransform:"uppercase",marginBottom:8}}>Tu diagnóstico</div>
        <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:26,color:"#fff",letterSpacing:"-1px",lineHeight:1.15,marginBottom:14}}>{data.titulo}</h2>
        <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#aaa",lineHeight:1.7}}>{data.resumen}</p>
      </div>
      <div style={{marginTop:20,display:"flex",flexDirection:"column",gap:10}}>
        <div className="result-card" style={{animationDelay:".3s"}}>
          <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#4ade80",letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:8}}>💪 Tu fortaleza</div>
          <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#ccc",lineHeight:1.6}}>{data.fortaleza}</p>
        </div>
        <div className="result-card" style={{animationDelay:".4s"}}>
          <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#FF4B2B",letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:8}}>⚠️ Tu mayor riesgo</div>
          <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#ccc",lineHeight:1.6}}>{data.riesgo}</p>
        </div>
        <div className="result-card" style={{animationDelay:".5s",borderColor:"#FF4B2B22"}}>
          <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#facc15",letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:8}}>🎯 Tu primer paso</div>
          <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#ccc",lineHeight:1.6}}>{data.primer_paso}</p>
        </div>
      </div>
      <div style={{marginTop:20,animation:"resultSlide .5s ease .6s both",opacity:0}}>
        <button className="btn-primary" onClick={onContinue} style={{animation:"none"}}>
          Comenzar mis lecciones →
        </button>
        <button onClick={()=>{navigator.clipboard.writeText(`🔥 Mi diagnóstico Hendy${userName?" de "+userName:""}:\n"${data.titulo}"\n\nDescubrí el tuyo en hendy.app`).then(()=>setCopied(true));setTimeout(()=>setCopied(false),2000)}}
          className="btn-ghost" style={{borderColor:copied?"#4ade80":"#1e1e1e",color:copied?"#4ade80":"#555"}}>
          {copied?"✅ Copiado para compartir":"📤 Compartir mi diagnóstico"}
        </button>
      </div>
    </div>
  );
};

// ─── ACADEMY ──────────────────────────────────────────────────────────────────
const FREE_LESSONS = 2; // lecciones gratis antes del paywall

const Academy = ({userData,streak,completed,onComplete,userName,isPro,onUpgrade}) => {
  const [active,setActive]=useState(null);
  const [content,setContent]=useState(null);
  const [loading,setLoading]=useState(false);
  const [done,setDone]=useState(false);
  const [timer,setTimer]=useState(60);
  const [timerOn,setTimerOn]=useState(false);

  useEffect(()=>{
    if(!timerOn||timer<=0)return;
    const t=setInterval(()=>setTimer(s=>s-1),1000);
    return()=>clearInterval(t);
  },[timerOn,timer]);

  const openLesson=async(l)=>{
    if(completed.includes(l.id))return;
    setActive(l);setContent(null);setLoading(true);setDone(false);setTimer(60);setTimerOn(false);
    const prompt=`Sos Hendy, el coach financiero más cercano y honesto de Paraguay. Hablás como alguien del barrio, sin tecnicismos.
Usuario: ${userName||"alguien"} — diagnóstico: "${userData?.diagnostico?.titulo||"situación difícil"}"
Generá micro-lección de 60 segundos sobre: "${l.titulo}"
SOLO JSON puro sin markdown:
{"gancho":"<frase impactante 10 palabras>","cuerpo":"<3-4 párrafos cortos separados por doble salto de línea, lenguaje simple, ejemplos paraguayos>","dato_clave":"<1 dato sorprendente>","accion":"<1 cosa concreta HOY, 15 palabras max>"}`;
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:prompt}]})});
      const data=await res.json();
      const text=data.content?.find(b=>b.type==="text")?.text||"{}";
      const parsed=JSON.parse(text.replace(/```json|```/g,"").trim());
      setContent({
        gancho:    typeof parsed.gancho     ==="string"?parsed.gancho    :"¿Estás listo para cambiar tu relación con la plata?",
        cuerpo:    typeof parsed.cuerpo     ==="string"?parsed.cuerpo    :"Cargando contenido...",
        dato_clave:typeof parsed.dato_clave ==="string"?parsed.dato_clave:"",
        accion:    typeof parsed.accion     ==="string"?parsed.accion    :"",
      });
      setTimerOn(true);
    }catch{
      setContent({
        gancho:"¿Sabías que el 80% gasta antes de ahorrar — y por eso nunca ahorra?",
        cuerpo:"El truco del sobre es una de las técnicas más simples y efectivas para manejar la plata.\n\nDividís tu ingreso en sobres: comida, transporte, servicios, y lo que queda.\n\nCuando el sobre de comida se vacía, terminó. No hay debate, no hay tarjeta.\n\nEn Paraguay funciona especialmente bien para trabajadores independientes y feriantes.",
        dato_clave:"Las personas que usan sobres ahorran hasta 30% más en su primer mes — sin ganar más.",
        accion:"Esta semana, separá tu plata en 4 partes apenas la recibas.",
      });
      setTimerOn(true);
    }
    setLoading(false);
  };

  const finish=()=>{
    setDone(true);setTimerOn(false);
    setTimeout(()=>{onComplete(active.id);setActive(null);setContent(null);setDone(false);},1800);
  };

  if(active){
    return(
      <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"56px 28px 40px",animation:"fadeIn .4s ease"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:32}}>
          <button onClick={()=>setActive(null)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontFamily:"'DM Sans',sans-serif",fontSize:14,padding:0}}>← Volver</button>
          {timerOn&&<div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:13,color:timer>20?"#FF4B2B":"#4ade80",background:"#111",border:"1px solid #1e1e1e",borderRadius:100,padding:"6px 14px"}}>{timer>0?`⏱ ${timer}s`:"✅ Listo"}</div>}
        </div>
        {loading?(
          <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
            <div style={{fontSize:48,animation:"flicker 1.5s ease infinite",marginBottom:20}}>{active.emoji}</div>
            <div style={{display:"flex",gap:8}}><span className="typing-dot"/><span className="typing-dot"/><span className="typing-dot"/></div>
          </div>
        ):content?(
          <div style={{flex:1,animation:"lessonIn .5s ease"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:24}}>
              <span style={{fontSize:36}}>{active.emoji}</span>
              <div>
                <span className="category-pill" style={{background:`${catColor[active.categoria]}20`,color:catColor[active.categoria]}}>{active.categoria}</span>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:22,color:"#fff",letterSpacing:"-.5px",marginTop:6}}>{active.titulo}</div>
              </div>
            </div>
            <div style={{background:"#130a09",border:"1px solid #FF4B2B33",borderRadius:16,padding:"16px 20px",marginBottom:20}}>
              <p style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:16,color:"#FF4B2B",lineHeight:1.5}}>"{content.gancho}"</p>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:14,marginBottom:20}}>
              {(content.cuerpo||"").split("\n\n").filter(Boolean).map((p,i)=>(
                <p key={i} style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:15,color:"#bbb",lineHeight:1.75}}>{p}</p>
              ))}
            </div>
            {content.dato_clave&&(
              <div style={{background:"#0d1a0d",border:"1px solid #4ade8033",borderRadius:16,padding:"16px 20px",marginBottom:16}}>
                <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#4ade80",letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:8}}>📊 Dato clave</div>
                <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:400,fontSize:14,color:"#ccc",lineHeight:1.6}}>{content.dato_clave}</p>
              </div>
            )}
            {content.accion&&(
              <div style={{background:"#1a1208",border:"1px solid #facc1533",borderRadius:16,padding:"16px 20px",marginBottom:28}}>
                <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#facc15",letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:8}}>🎯 Tu acción de hoy</div>
                <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:500,fontSize:15,color:"#fff",lineHeight:1.5}}>{content.accion}</p>
              </div>
            )}
            {done?(
              <div style={{textAlign:"center",animation:"checkPop .5s ease"}}>
                <div style={{fontSize:64,marginBottom:12}}>✅</div>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:22,color:"#4ade80"}}>¡Lección completada!</div>
                <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:14,color:"#555",marginTop:8}}>Tu racha sigue creciendo 🔥</div>
              </div>
            ):(
              <button className="btn-primary" onClick={finish} style={{animation:"none"}}>Marcar como completada ✓</button>
            )}
          </div>
        ):null}
      </div>
    );
  }

  const todayL=LECCIONES_BASE.find(l=>!completed.includes(l.id));
  const prog=Math.round((completed.length/LECCIONES_BASE.length)*100);
  return(
    <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"56px 28px 100px",animation:"fadeIn .4s ease"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:24}}>
        <div>
          <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:26,color:"#fff",letterSpacing:"-1px"}}>Academia</div>
          <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#555",marginTop:4}}>Aprendé un poco cada día</div>
        </div>
        <div className="streak-badge"><span style={{fontSize:20}}>🔥</span><span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:18,color:"#FF4B2B"}}>{streak}</span><span style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:"#666"}}>días</span></div>
      </div>
      <div style={{background:"#0e0e0e",border:"1px solid #1e1e1e",borderRadius:20,padding:"18px 20px",marginBottom:20}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:14,color:"#ddd"}}>Tu progreso</div>
          <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:13,color:"#FF4B2B",fontWeight:500}}>{completed.length}/{LECCIONES_BASE.length}</div>
        </div>
        <div className="progress-bar-bg"><div className="progress-bar-fill" style={{"--prog":`${prog}%`}}/></div>
        <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#444",marginTop:10}}>
          {prog===0?"Empezá hoy — una lección cambia todo.":prog<50?"¡Vas bien!":prog<100?"Ya más de la mitad 💪":"¡Completaste todo! 🏆"}
        </div>
      </div>
      {todayL&&(
        <div style={{marginBottom:16}}>
          <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#FF4B2B",letterSpacing:"2px",textTransform:"uppercase",marginBottom:10}}>📅 Lección de hoy</div>
          <button className="lesson-card active-today" onClick={()=>openLesson(todayL)}>
            <div style={{display:"flex",alignItems:"flex-start",gap:14}}>
              <span style={{fontSize:32,flexShrink:0}}>{todayL.emoji}</span>
              <div style={{flex:1}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                  <span className="category-pill" style={{background:`${catColor[todayL.categoria]}20`,color:catColor[todayL.categoria]}}>{todayL.categoria}</span>
                  <span style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:"#555"}}>⏱ {todayL.duracion}</span>
                </div>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:16,color:"#fff",marginBottom:6}}>{todayL.titulo}</div>
                <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#666",lineHeight:1.5}}>{todayL.preview}</div>
              </div>
            </div>
            <div style={{marginTop:12,padding:"10px 0 0",borderTop:"1px solid #1e1e1e",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{fontFamily:"'DM Sans',sans-serif",fontSize:12,color:"#FF4B2B",fontWeight:500}}>Empezar →</span>
            </div>
          </button>
        </div>
      )}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
        <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#444",letterSpacing:"2px",textTransform:"uppercase"}}>Todas las lecciones</div>
        {!isPro&&<div style={{display:"inline-flex",alignItems:"center",gap:6,background:"#1a1208",border:"1px solid #facc1533",borderRadius:100,padding:"4px 10px"}}>
          <span style={{fontSize:10}}>⭐</span>
          <span style={{fontFamily:"'DM Sans',sans-serif",fontSize:10,color:"#facc15"}}>{FREE_LESSONS} gratis · Pro ilimitado</span>
        </div>}
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        {LECCIONES_BASE.map((l,i)=>{
          const isDone=completed.includes(l.id);
          const isLocked=!isPro && i>=FREE_LESSONS && !isDone;
          const handleClick=()=>{
            if(isLocked){onUpgrade();return;}
            if(!isDone) openLesson(l);
          };
          return(
            <button key={l.id} className={`lesson-card${isDone?" completed":""}`}
              onClick={handleClick}
              style={{opacity:isDone?.65:1,animationDelay:`${i*.05}s`,cursor:isDone?"default":"pointer",position:"relative",overflow:"hidden"}}>
              <div style={{display:"flex",alignItems:"center",gap:14,filter:isLocked?"blur(1px)":"none"}}>
                <span style={{fontSize:26,flexShrink:0}}>{isDone?"✅":l.emoji}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:14,color:isDone?"#555":"#ddd",marginBottom:3}}>{l.titulo}</div>
                  <div style={{display:"flex",gap:8,alignItems:"center"}}>
                    <span className="category-pill" style={{background:`${catColor[l.categoria]}15`,color:isDone?"#444":catColor[l.categoria]}}>{l.categoria}</span>
                    <span style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:"#444"}}>⏱ {l.duracion}</span>
                  </div>
                </div>
                {isDone?<span style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:"#4ade80"}}>Lista</span>:<span style={{color:"#333",fontSize:16}}>›</span>}
              </div>
              {isLocked&&(
                <div className="lock-overlay">
                  <span style={{fontSize:22}}>🔒</span>
                  <span style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:12,color:"#facc15"}}>Hendy Pro</span>
                </div>
              )}
            </button>
          );
        })}
      </div>
      {!isPro&&(
        <div style={{marginTop:20,background:"linear-gradient(135deg,#1a1208,#120a1a)",border:"1px solid #facc1544",borderRadius:20,padding:20}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
            <span style={{fontSize:22}}>⭐</span>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:15,color:"#facc15"}}>Desbloqueá todo con Pro</div>
          </div>
          <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#666",lineHeight:1.6,marginBottom:14}}>
            Por solo $2/mes tenés todas las lecciones, plan personalizado y seguimiento de metas.
          </p>
          <button onClick={onUpgrade} style={{background:"linear-gradient(135deg,#facc15,#f59e0b)",color:"#000",border:"none",borderRadius:14,padding:"14px 20px",fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:14,cursor:"pointer",width:"100%"}}>
            Ver Hendy Pro →
          </button>
        </div>
      )}
    </div>
  );
};

// ─── LOGROS ───────────────────────────────────────────────────────────────────
const Logros = ({completed,streak,userData}) => {
  const earned = BADGES.filter(b=>b.req(completed.length,streak,userData));
  return(
    <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"56px 28px 100px",animation:"fadeIn .4s ease"}}>
      <div style={{marginBottom:28}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:26,color:"#fff",letterSpacing:"-1px"}}>Tus logros</div>
        <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#555",marginTop:4}}>{earned.length} de {BADGES.length} ganados</div>
      </div>
      <div style={{background:"#0e0e0e",border:"1px solid #1e1e1e",borderRadius:20,padding:"18px 20px",marginBottom:24}}>
        <div className="progress-bar-bg" style={{marginBottom:10}}>
          <div className="progress-bar-fill" style={{"--prog":`${Math.round(earned.length/BADGES.length*100)}%`,background:"#facc15"}}/>
        </div>
        <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#444"}}>
          {earned.length===0?"Completá tu primera lección para desbloquear logros.":earned.length===BADGES.length?"¡Colección completa! Sos un crack. 🏆":`${BADGES.length-earned.length} logros por desbloquear.`}
        </div>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        {BADGES.map((b,i)=>{
          const isEarned=b.req(completed.length,streak,userData);
          return(
            <div key={b.id} className={`badge-card${isEarned?" earned":" locked"}`}
              style={{animation:isEarned?`badgePop .5s ease ${i*.07}s both`:`fadeIn .3s ease ${i*.05}s both`}}>
              <div style={{width:52,height:52,borderRadius:14,background:isEarned?"#1a1208":"#111",
                border:`1px solid ${isEarned?"#facc1544":"#1e1e1e"}`,display:"flex",alignItems:"center",
                justifyContent:"center",fontSize:26,flexShrink:0,filter:isEarned?"none":"grayscale(1)"}}>
                {b.emoji}
              </div>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:14,color:isEarned?"#fff":"#333",marginBottom:3}}>{b.titulo}</div>
                <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:isEarned?"#666":"#2a2a2a"}}>{b.desc}</div>
              </div>
              {isEarned&&<div style={{fontSize:16}}>✨</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
};


// ─── PRO SCREEN ───────────────────────────────────────────────────────────────
const ProScreen = ({userName, onActivate, onBack}) => (
  <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"56px 28px 40px",animation:"fadeIn .4s ease"}}>
    <button onClick={onBack} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontFamily:"'DM Sans',sans-serif",fontSize:14,display:"flex",alignItems:"center",gap:8,marginBottom:36,padding:0}}>← Volver</button>
    <div style={{textAlign:"center",marginBottom:32}}>
      <div style={{fontSize:52,marginBottom:16,animation:"proGlow 2s ease infinite"}}>🔥</div>
      <div style={{display:"inline-flex",alignItems:"center",gap:8,background:"#1a1208",border:"1px solid #facc1544",borderRadius:100,padding:"6px 16px",marginBottom:16}}>
        <span style={{fontSize:14}}>⭐</span>
        <span style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:13,color:"#facc15"}}>HENDY PRO</span>
      </div>
      <h1 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:34,color:"#fff",letterSpacing:"-1.5px",lineHeight:1.1,marginBottom:12}}>
        Aprendé sin<br/><span style={{color:"#facc15"}}>límites.</span>
      </h1>
      <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:15,color:"#555",lineHeight:1.7}}>
        {userName?`${userName}, desbloqueá`:"Desbloqueá"} todas las lecciones y salí de Hendy más rápido.
      </p>
    </div>
    <div className="pro-banner" style={{marginBottom:24,animation:"proGlow 3s ease infinite"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:40,color:"#facc15",letterSpacing:"-2px",textAlign:"center",lineHeight:1}}>$2<span style={{fontSize:16,color:"#666",fontWeight:300}}>/mes</span></div>
      <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:12,color:"#555",textAlign:"center",marginTop:4}}>Menos que un tereré en el centro 🧉</div>
      <div style={{marginTop:20,display:"flex",flexDirection:"column"}}>
        {[
          {icon:"📚",label:"Lecciones ilimitadas todos los días"},
          {icon:"🧠",label:"Plan financiero personalizado con IA"},
          {icon:"🎯",label:"Seguimiento de metas y gastos"},
          {icon:"🏆",label:"Todos los logros desbloqueados"},
          {icon:"🔕",label:"Sin límites ni interrupciones"},
        ].map((f,i)=>(
          <div key={i} className="pro-feature">
            <span style={{fontSize:20,flexShrink:0}}>{f.icon}</span>
            <span style={{fontFamily:"'DM Sans',sans-serif",fontWeight:400,fontSize:14,color:"#ccc"}}>{f.label}</span>
            <span style={{marginLeft:"auto",color:"#facc15",fontSize:14}}>✓</span>
          </div>
        ))}
      </div>
    </div>
    <button onClick={onActivate} style={{background:"linear-gradient(135deg,#facc15,#f59e0b)",color:"#000",border:"none",borderRadius:16,padding:"18px 36px",fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:16,cursor:"pointer",width:"100%",marginBottom:12,animation:"proGlow 2s ease infinite"}}>
      Activar Hendy Pro — $2/mes →
    </button>
    <div style={{textAlign:"center",fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#333",lineHeight:1.8}}>
      Cancelá cuando quieras · Sin compromisos<br/>Pago seguro · Próximamente MercadoPago 🔒
    </div>
  </div>
);

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
const FORM_LINK = "https://docs.google.com/forms/d/e/1FAIpQLSfAYTrxA5l0YYArp8fCUInihQpBtBDqQjD_xKcAESM66m-SKQ/viewform?usp=sharing";

const Dashboard = ({userData,streak,completed,onNav,userName,showToast}) => {
  const [waitlistDone, setWaitlistDone] = useState(false);
  const handleWaitlist = () => {
    if(FORM_LINK !== "TU_LINK_AQUI") window.open(FORM_LINK, "_blank");
    setWaitlistDone(true);
    showToast({emoji:"🔥", titulo:"¡Anotado!", desc:"Te avisamos cuando NXB esté listo."});
  };
  const prog=Math.round((completed.length/LECCIONES_BASE.length)*100);
  const scoreColor=(userData?.diagnostico?.score||0)>=70?"#4ade80":(userData?.diagnostico?.score||0)>=40?"#facc15":"#FF4B2B";
  const todayL=LECCIONES_BASE.find(l=>!completed.includes(l.id));
  const earnedCount=BADGES.filter(b=>b.req(completed.length,streak,userData)).length;
  return(
    <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"56px 28px 100px",animation:"fadeIn .5s ease"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:24}}>
        <div>
          <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#555",marginBottom:4}}>
            {userName?`Bienvenido/a, ${userName} 👋`:"Bienvenido/a de vuelta"}
          </div>
          <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:26,color:"#fff",letterSpacing:"-1px"}}>Tu panel Hendy 🔥</div>
        </div>
        <div className="streak-badge"><span style={{fontSize:18}}>🔥</span><span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:16,color:"#FF4B2B"}}>{streak}</span><span style={{fontFamily:"'DM Sans',sans-serif",fontSize:10,color:"#666"}}>días</span></div>
      </div>
      <div style={{background:"#0e0e0e",border:"1px solid #1e1e1e",borderRadius:20,padding:"20px",marginBottom:14,animation:"fadeUp .5s ease .1s both"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div>
            <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#444",letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:6}}>Tu puntaje</div>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:48,color:scoreColor,letterSpacing:"-2px",lineHeight:1}}>{userData?.diagnostico?.score||"—"}</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#555",lineHeight:1.6,maxWidth:150}}>{userData?.diagnostico?.titulo||"Completá tu diagnóstico"}</div>
          </div>
        </div>
        <div className="progress-bar-bg"><div className="progress-bar-fill" style={{"--prog":`${userData?.diagnostico?.score||0}%`,background:scoreColor}}/></div>
      </div>
      <div style={{display:"flex",gap:12,marginBottom:14,animation:"fadeUp .5s ease .2s both"}}>
        {[
          {label:"Lecciones",val:completed.length,sub:"completadas"},
          {label:"Progreso", val:`${prog}%`,sub:"del plan",c:"#FF4B2B"},
          {label:"Logros",   val:`${earnedCount}🏆`,sub:"ganados"},
        ].map((s,i)=>(
          <div key={i} className="stat-card">
            <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:"#444",letterSpacing:"1px",textTransform:"uppercase",marginBottom:6}}>{s.label}</div>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:22,color:s.c||"#fff",letterSpacing:"-1px"}}>{s.val}</div>
            <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:11,color:"#555",marginTop:2}}>{s.sub}</div>
          </div>
        ))}
      </div>
      {todayL&&(
        <div style={{animation:"fadeUp .5s ease .3s both",marginBottom:14}}>
          <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#FF4B2B",letterSpacing:"2px",textTransform:"uppercase",marginBottom:10}}>📅 Lección de hoy</div>
          <button className="lesson-card active-today" onClick={()=>onNav("academy")} style={{width:"100%"}}>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <span style={{fontSize:28}}>{todayL.emoji}</span>
              <div>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:15,color:"#fff"}}>{todayL.titulo}</div>
                <div style={{fontFamily:"'DM Sans',sans-serif",fontSize:12,color:"#FF4B2B",marginTop:3}}>Empezar ahora →</div>
              </div>
            </div>
          </button>
        </div>
      )}
      <div style={{background:"linear-gradient(135deg,#1a0a08,#0d0d1a)",border:"1px solid #2a1520",borderRadius:20,padding:20,animation:"fadeUp .5s ease .4s both"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:20}}>💸</span>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:14,color:"#ddd"}}>NXB · Pagos internacionales</div>
          </div>
          <div style={{background:"#1a1208",border:"1px solid #facc1533",borderRadius:100,padding:"4px 10px",
            fontFamily:"'DM Sans',sans-serif",fontSize:10,color:"#facc15",letterSpacing:"1px",textTransform:"uppercase",flexShrink:0}}>
            🚧 En desarrollo
          </div>
        </div>
        <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#666",lineHeight:1.6,marginBottom:14}}>
          Muy pronto podrás mover tu plata sin comisiones en todo el Mercosur. Anotate ahora y sé el primero en acceder.
        </p>
        {waitlistDone ? (
          <div style={{display:"flex",alignItems:"center",gap:12,padding:"14px 20px",
            background:"#0a130a",border:"1px solid #4ade8033",borderRadius:16,
            animation:"fadeIn .4s ease"}}>
            <span style={{fontSize:24}}>✅</span>
            <div>
              <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:14,color:"#4ade80"}}>¡Anotado!</div>
              <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#555",marginTop:2}}>
                Te avisamos cuando NXB esté listo 🔥
              </div>
            </div>
          </div>
        ) : (
          <button onClick={handleWaitlist} className="btn-primary"
            style={{animation:"none",padding:"13px 20px",fontSize:13,background:"#1a1208",color:"#facc15",border:"1px solid #facc1533"}}>
            Anotarme en la lista de espera →
          </button>
        )}
      </div>
    </div>
  );
};

// ─── PROFILE ──────────────────────────────────────────────────────────────────
const Profile = ({userData,streak,completed,onReset,userName,notifEnabled,onToggleNotif,isPro}) => (
  <div style={{width:"100%",maxWidth:390,minHeight:"100vh",display:"flex",flexDirection:"column",padding:"56px 28px 100px",animation:"fadeIn .4s ease"}}>
    <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:26,color:"#fff",letterSpacing:"-1px",marginBottom:24}}>Tu perfil</div>
    <div style={{background:"#0e0e0e",border:"1px solid #1e1e1e",borderRadius:20,padding:20,marginBottom:14}}>
      <div style={{display:"flex",alignItems:"center",gap:16,marginBottom:20}}>
        <div style={{width:56,height:56,borderRadius:16,background:"#1a0d09",border:"2px solid #FF4B2B",
          display:"flex",alignItems:"center",justifyContent:"center",fontSize:28}}>🔥</div>
        <div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:18,color:"#fff"}}>{userName||"Usuario Hendy"}</div>
            {isPro&&<div style={{background:"#1a1208",border:"1px solid #facc1544",borderRadius:100,padding:"2px 8px",fontFamily:"'DM Sans',sans-serif",fontSize:10,color:"#facc15",fontWeight:600}}>⭐ PRO</div>}
          </div>
          <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#555",marginTop:3}}>{isPro?"Plan Pro activo 🔥":"En camino de salir 💪"}</div>
        </div>
      </div>
      {[
        {label:"Racha actual",val:`${streak} días 🔥`},
        {label:"Lecciones completadas",val:`${completed.length} de ${LECCIONES_BASE.length}`},
        {label:"Puntaje Hendy",val:userData?.diagnostico?.score||"—"},
      ].map((s,i)=>(
        <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 0",borderBottom:i<2?"1px solid #161616":"none"}}>
          <span style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#555"}}>{s.label}</span>
          <span style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:14,color:"#ddd"}}>{s.val}</span>
        </div>
      ))}
    </div>

    {/* Notificaciones */}
    <div style={{background:"#0e0e0e",border:"1px solid #1e1e1e",borderRadius:20,padding:20,marginBottom:14}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:15,color:"#ddd",marginBottom:4}}>🔔 Recordatorio diario</div>
          <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#555"}}>
            {notifEnabled?"Recibirás un recordatorio a las 8:00 AM":"Te recordamos tu lección del día"}
          </div>
        </div>
        <button onClick={onToggleNotif} style={{
          width:52,height:28,borderRadius:100,border:"none",cursor:"pointer",
          background:notifEnabled?"#FF4B2B":"#2a2a2a",position:"relative",transition:"background .3s",flexShrink:0,
        }}>
          <div style={{
            width:20,height:20,borderRadius:50,background:"#fff",position:"absolute",
            top:4,transition:"left .3s",left:notifEnabled?28:4,
          }}/>
        </button>
      </div>
      {notifEnabled&&(
        <div style={{marginTop:14,padding:"10px 14px",background:"#130a09",border:"1px solid #FF4B2B22",borderRadius:12,
          fontFamily:"'DM Sans',sans-serif",fontSize:12,color:"#666",lineHeight:1.6,animation:"fadeIn .3s ease"}}>
          📱 Activá las notificaciones del navegador cuando lo instales como app para recibir el recordatorio.
        </div>
      )}
    </div>

    {userData?.diagnostico?.primer_paso&&(
      <div style={{background:"#0e0e0e",border:"1px solid #1e1e1e",borderRadius:20,padding:20,marginBottom:14}}>
        <div style={{fontSize:11,fontFamily:"'DM Sans',sans-serif",color:"#444",letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:12}}>Tu diagnóstico</div>
        <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:14,color:"#888",lineHeight:1.7,marginBottom:14}}>{userData.diagnostico.titulo}</p>
        <div style={{padding:"12px 16px",background:"#1a1208",border:"1px solid #facc1522",borderRadius:12}}>
          <div style={{fontSize:11,color:"#facc15",fontFamily:"'DM Sans',sans-serif",letterSpacing:"1px",textTransform:"uppercase",marginBottom:6}}>🎯 Tu próximo paso</div>
          <p style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:13,color:"#ccc",lineHeight:1.6}}>{userData.diagnostico.primer_paso}</p>
        </div>
      </div>
    )}
    <button onClick={onReset} className="btn-ghost" style={{marginTop:0}}>🔄 Repetir diagnóstico</button>
    <div style={{textAlign:"center",marginTop:24,fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:12,color:"#222"}}>hendy · Paraguay 🔥 v1.0</div>
  </div>
);

// ─── BOTTOM NAV ───────────────────────────────────────────────────────────────
const BottomNav = ({active,onNav}) => (
  <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:390,
    background:"rgba(10,10,10,.95)",backdropFilter:"blur(20px)",borderTop:"1px solid #161616",
    display:"flex",zIndex:50,paddingBottom:"env(safe-area-inset-bottom)"}}>
    {[{id:"dashboard",icon:"🏠",label:"Inicio"},{id:"academy",icon:"📚",label:"Academia"},
      {id:"logros",icon:"🏆",label:"Logros"},{id:"profile",icon:"👤",label:"Perfil"}].map(n=>(
      <button key={n.id} className="nav-btn" onClick={()=>onNav(n.id)}>
        <span style={{fontSize:20,filter:active===n.id?"none":"grayscale(1)",opacity:active===n.id?1:.35,transition:"all .2s"}}>{n.icon}</span>
        <span style={{fontFamily:"'DM Sans',sans-serif",fontSize:10,color:active===n.id?"#FF4B2B":"#444",fontWeight:active===n.id?500:300,transition:"color .2s"}}>{n.label}</span>
      </button>
    ))}
  </div>
);

// ─── TOAST ────────────────────────────────────────────────────────────────────
const Toast = ({msg}) => (
  <div className="toast">
    <span style={{fontSize:20}}>{msg.emoji}</span>
    <div>
      <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:13,color:"#fff"}}>{msg.titulo}</div>
      <div style={{fontFamily:"'DM Sans',sans-serif",fontWeight:300,fontSize:11,color:"#666"}}>{msg.desc}</div>
    </div>
  </div>
);

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function HendyApp() {
  const [screen,setScreen]         = useState("splash");
  const [splashDone,setSplash]     = useState(false);
  const [userName,setUserName]     = useState("");
  const [userData,setUserData]     = useState(null);
  const [streak,setStreak]         = useState(3);
  const [completed,setCompleted]   = useState([]);
  const [navTab,setNavTab]         = useState("dashboard");
  const [notifEnabled,setNotif]    = useState(false);
  const [isPro,setIsPro]           = useState(false);
  const [toast,setToast]           = useState(null);

  useEffect(()=>{
    setTimeout(()=>setSplash(true),2800);
    setTimeout(()=>setScreen("name"),3300);
  },[]);

  const showToast=(msg)=>{setToast(msg);setTimeout(()=>setToast(null),3500);};

  const callAI=async(answers)=>{
    setScreen("loading");
    const prompt=`Sos el coach financiero de Hendy para Paraguay y Mercosur. Usuario: ${userName||"alguien"}.
Situación: ${answers.situacion}. Deudas: ${answers.deuda}. Meta: ${answers.meta}.
SOLO JSON puro:
{"score":<10-90>,"titulo":"<máx 8 palabras>","resumen":"<2-3 oraciones>","fortaleza":"<1-2 oraciones>","riesgo":"<1-2 oraciones>","primer_paso":"<acción concreta>"}`;
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:prompt}]})});
      const data=await res.json();
      const text=data.content?.find(b=>b.type==="text")?.text||"{}";
      const diag=JSON.parse(text.replace(/```json|```/g,"").trim());
      setUserData({answers,diagnostico:diag});setScreen("result");
    }catch{
      setUserData({answers,diagnostico:{score:38,titulo:"Estás en modo supervivencia — y eso cambia.",
        resumen:"Sabés lo que es llegar ajustado. Pero el hecho de que estés acá ya es diferente a ayer.",
        fortaleza:"Reconocés tu situación sin negarlo. Esa honestidad es tu mayor activo.",
        riesgo:"Sin un plan mínimo de gastos, cada mes empieza desde cero.",
        primer_paso:"Esta semana, anotá cuánto entra y cuánto sale. Solo eso.",
      }});setScreen("result");
    }
  };

  const completeLesson=(id)=>{
    const newCompleted=[...completed,id];
    setCompleted(newCompleted);
    setStreak(s=>s+1);
    // Check badge unlock
    const prev=BADGES.filter(b=>b.req(completed.length,streak,userData));
    const next=BADGES.filter(b=>b.req(newCompleted.length,streak+1,userData));
    const newBadge=next.find(b=>!prev.find(p=>p.id===b.id));
    if(newBadge) setTimeout(()=>showToast({emoji:newBadge.emoji,titulo:"¡Nuevo logro! "+newBadge.titulo,desc:newBadge.desc}),1500);
  };

  const toggleNotif=()=>{
    const next=!notifEnabled;
    setNotif(next);
    if(next) showToast({emoji:"🔔",titulo:"Recordatorio activado",desc:"Te avisamos todos los días a las 8:00 AM"});
    else showToast({emoji:"🔕",titulo:"Recordatorio desactivado",desc:"Podés activarlo cuando quieras"});
  };

  const renderApp=()=>(
    <>
      {navTab==="dashboard"&&<Dashboard userData={userData} streak={streak} completed={completed} onNav={setNavTab} userName={userName} showToast={showToast}/>}
      {navTab==="academy"  &&<Academy   userData={userData} streak={streak} completed={completed} onComplete={completeLesson} userName={userName} isPro={isPro} onUpgrade={()=>setNavTab('pro')}/>}
      {navTab==="logros"   &&<Logros    completed={completed} streak={streak} userData={userData}/>}
      {navTab==="profile"  &&<Profile   userData={userData} streak={streak} completed={completed} userName={userName}
        notifEnabled={notifEnabled} onToggleNotif={toggleNotif} isPro={isPro}
        onReset={()=>{setUserData(null);setCompleted([]);setScreen("name");setNavTab("dashboard");setUserName("");}}/>}
      {navTab==="pro"      &&<ProScreen userName={userName} onActivate={()=>{setIsPro(true);setNavTab("academy");showToast({emoji:"🔥",titulo:"¡Bienvenido a Hendy Pro!",desc:"Acceso ilimitado activado."});}} onBack={()=>setNavTab("academy")}/>}
      <BottomNav active={navTab} onNav={setNavTab}/>
    </>
  );

  return(
    <div style={{fontFamily:"'Syne',sans-serif",background:"#0A0A0A",minHeight:"100vh",
      display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",position:"relative"}}>
      <style>{CSS}</style>
      <Ambient/>
      {toast&&<Toast msg={toast}/>}
      {screen==="splash" &&<Splash done={splashDone}/>}
      {screen==="name"   &&<NameScreen onContinue={(n)=>{setUserName(n);setScreen("home");}}/>}
      {screen==="home"   &&<Home onStart={()=>setScreen("quiz")} userName={userName}/>}
      {screen==="quiz"   &&<Quiz onFinish={callAI} onBack={()=>setScreen("home")} userName={userName}/>}
      {screen==="loading"&&<Loading userName={userName}/>}
      {screen==="result" &&userData&&<Result data={userData.diagnostico} userName={userName} onContinue={()=>{setScreen("app");setNavTab("dashboard");}}/>}
      {screen==="app"    &&renderApp()}
    </div>
  );
}
